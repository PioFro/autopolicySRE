/*
 * Copyright 2018-present Open Networking Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.rnn;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.onlab.packet.IpAddress;
import org.onosproject.net.DeviceId;
import org.onosproject.net.HostId;
import org.onosproject.rest.AbstractWebResource;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import java.io.InputStream;
import java.lang.reflect.Field;

/**
 * Handler for rest input. Reveives information about host and devices security
 * @author Piotr Frohlich
 * @version Beta 2.0.0
 */
@Path("PVT")
public class AppWebResource extends AbstractWebResource {

    String METRICS = "metric";
    String IP = "ip";
    String ONOS_HOST = "onos_host";
    String HOST_ID = "id";
    String EXPLANATION = "explanation";
    String DEVICE_ID = "device id";
    String SENSITIVITY = "sensitivity";
    String ACTION = "action";
    String MITIGATION = "m";
    String UNMITIGATE = "u";

    String DESTINATION_DEVICE_IP = "Device_IP4";
    String SOURCE_DEVICE_IP = "Login_IP4";
    String ACTION_HLAD = "Action";
    String LOG_OF_EVENT = "Event";

    /**
     * POST security info about host.
     *
     * JSON file must consist of:
     * <p>IP address (key "ip")</p>
     * <p>Security Metric (key "metric")</p>
     * <p>Host ID (key "id")</p>
     * <p>Explanation (key "explanation")</p>
     * @return 200 OK
     */
    @POST
    @Path("metrics")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response getGreeting(InputStream stream) {
        ObjectNode node;
        try {
            ObjectNode jsonTree = (ObjectNode) mapper().readTree(stream);

            JsonNode hostIP = jsonTree.get(IP);
            JsonNode metric = jsonTree.get(METRICS);
            JsonNode hostID = jsonTree.get(ONOS_HOST);
            JsonNode explanation = jsonTree.get(EXPLANATION);
            HostId hostId = HostId.hostId(hostID.get(HOST_ID).asText());

            RnnRouting.MASTER.log.info("### NEW SECURITY RECORD FOR " + hostIP.asText() + " VALUE: " + metric.asText());
            NetState.addSecureHost(new SecureHost(hostId, metric.asInt(), hostIP.asText(), explanation.asText()));
            NetState.setParamsChanged();




            node = mapper().createObjectNode().put(hostID.get(HOST_ID).asText(), metric.asText());
        } catch (Exception e) {
            node = mapper().createObjectNode().put("ERROR", e.getMessage());
        }
        return ok(node).build();
    }

    /**
     * POST sensitivity information about given device. JSON file must contain:
     * <p>Device id (key "device id")</p>
     * <p>Sensitivity of given device (key "sensitivity")</p>
     *
     * @return 200 OK
     */
    @POST
    @Path("devices")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response getDevicesSensitivity(InputStream stream) {
        ObjectNode node;
        try {

            ObjectNode jsonTree = (ObjectNode) mapper().readTree(stream);

            JsonNode device = jsonTree.get(DEVICE_ID);
            JsonNode sensitivity = jsonTree.get(SENSITIVITY);

            RnnRouting.MASTER.log.info("### NEW SENSITIVITY RECORD FOR " + device.asText() + " VALUE: " + sensitivity.asText());
            NetState.getTopology().get(NetState.getForwardingDeviceByDeviceID(DeviceId.deviceId(device.asText()))).setSensivity(sensitivity.asInt());

            NetState.setParamsChanged();

            node = mapper().createObjectNode().put(device.asText(), sensitivity.asText());
        } catch (Exception e) {
            node = mapper().createObjectNode().put("ERROR", e.getMessage());
        }
        return ok(node).build();
    }

    /**
     * Javadoc
     * @param stream stream
     * @return response
     */
    @POST
    @Path("hlad")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response deleteDevice(InputStream stream) {
        ObjectNode node;
        node = mapper().createObjectNode().put("Received honeypot reroute query","Version 2.1.3");
        try
        {
            ObjectNode jsonTree = (ObjectNode) mapper().readTree(stream);

            JsonNode destinationDevice = jsonTree.get(DESTINATION_DEVICE_IP);
            JsonNode attackingDevice = jsonTree.get(SOURCE_DEVICE_IP);
            JsonNode logReason = jsonTree.get(LOG_OF_EVENT);
            JsonNode action = jsonTree.get(ACTION_HLAD);

            RnnRouting.MASTER.log.info("Device: "+destinationDevice.asText() + " is attacked by: "+attackingDevice.asText()+ " discovered reason: "+logReason.asText()+ " taken action: "+action.asText());

            HostId destinationHost = RnnRouting.MASTER.getHostIdByIpAddress(IpAddress.valueOf(destinationDevice.asText()));
            HostId attackingHost = RnnRouting.MASTER.getHostIdByIpAddress(IpAddress.valueOf(attackingDevice.asText()));
            HostId honeypotHostId = RnnRouting.MASTER.getHostIdByIpAddress(IpAddress.valueOf(NetState.HONEYPOT_IP));

            if(destinationHost == null)
            {
                node.put("Destination host unknown", destinationDevice.asText());
            }
            if(attackingHost == null)
            {
                node.put("Attacking host unknown", attackingDevice.asText());
            }
            if(honeypotHostId == null)
            {
                node.put("Honeypot host unknown", NetState.HONEYPOT_IP);
            }
            VisAppComp.setHostTwo(NetState.getBySimpleID(NetState.getSimpleIDByIdOfConnectedHost(honeypotHostId)).getDeviceControllerId().toString());
            try {
                RnnRouting.MASTER.maskMovemement(destinationHost, honeypotHostId, attackingHost, true);
            }
            catch (Exception exc)
            {
                node.put("Error with installing rule", action.asText());
                node.put("dst",destinationDevice.asText());
                node.put("src", attackingDevice.asText());
                node.put("honeypot", honeypotHostId.toString());
            }
            node.put("Installing rule ended successfully", action.asText());
            node.put("dst",destinationDevice.asText());
            node.put("src", attackingDevice.asText());
            node.put("honeypot", honeypotHostId.toString());
        }
        catch (Exception e)
        {
            node.put("ERROR", e.getLocalizedMessage());
        }


        return  ok(node).build();

    }
    @POST
    @Path("parameters")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response setParameters(InputStream stream)
    {
        BlockChainAlertManager.sendAlert("TRY THIS", "TRY");
        ObjectNode node;
        node = mapper().createObjectNode().put("Changing parameters","Version 2.0.3");
        try
        {
            ObjectNode jsonTree = (ObjectNode) mapper().readTree(stream);

            Field[] fields = NetState.class.getDeclaredFields();
            for (int i = 0; i <fields.length; i++)
            {
                JsonNode param = jsonTree.get(fields[i].getName());
                if(param!= null)
                {
                    Object obj = fields[i].get(Class.forName("org.rnn.NetState"));

                    if(fields[i].getAnnotatedType().getType()==Double.TYPE)
                    {
                        fields[i].setDouble(obj, param.asDouble());
                    }
                    if(fields[i].getAnnotatedType().getType()==Integer.TYPE)
                    {
                        fields[i].setInt(obj, param.asInt());
                    }
                    try
                    {
                        fields[i].set(obj, param.asText());
                    }
                    catch(Exception e)
                    {
                        node.put("EXCEPTION",e.getMessage());
                    }
                    node.put(fields[i].getName(), param.asText());

                    if(fields[i].getName().equals("HONEYPOT_IP"))
                    {
                        try {
                            NetState.HONEYPOT_IP = jsonTree.get("HONEYPOT_IP").asText();
                        }
                        catch (Exception exc)
                        {}
                    }
                }
            }
        }
        catch (Exception e)
        {
            node.put("ERROR", e.getLocalizedMessage());

        }

        return  ok(node).build();
    }

}

