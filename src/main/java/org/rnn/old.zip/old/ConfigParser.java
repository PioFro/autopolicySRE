package org.rnn;

import java.io.File;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Scanner;

import com.eclipsesource.json.JsonObject;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.onlab.packet.IpAddress;
import org.onosproject.net.DeviceId;
import org.onosproject.net.PortNumber;
import org.rnn.json.*;


public class ConfigParser
{
    private static String CONFIGURATION = "config";
    private static String PORT = "port";
    private static String LOCAL = "LOCAL";
    private static String DEVICE = "device id";
    private static String IP_ADDRESS = "ip";
    public static AppComponent MASTER;
    private static String CONFIG_PATH = "/home/seriot-controller/.onos-config/config.json";

    private static String configString = "";




    static public ArrayList<Daemon> getDaemons()
    {
        ArrayList<Daemon> daemons = new ArrayList<>();
        String configJson = "";

        try
        {
            Scanner scanner = new Scanner(new File(CONFIG_PATH));
            configJson = scanner.useDelimiter("\\A").next();
            scanner.close();
        }
        catch (Exception e)
        {
            try {
                Scanner scanner = new Scanner(new File("/home/pfrohlich/.onos-config/config.json"));
                configJson = scanner.useDelimiter("\\A").next();
                scanner.close();
            }
            catch (Exception e2)
            {
                try {
                    Scanner scanner = new Scanner(new File("/home/seriot/.onos-config/config.json"));
                    configJson = scanner.useDelimiter("\\A").next();
                    scanner.close();
                }
                catch (Exception e1)
                {}
            }
        }
        if(configJson.equals("ERROR"))
        {
            MASTER.log.error("Unable to locate file in : "+CONFIG_PATH);

        }
        else
        {
            configString = configJson;
            try {


                JSONObject tmp = new JSONObject(configJson);

                try {
                    NetState.VISUALISATION_IP_ADDRESS = tmp.getString("visualisation ip");
                }
                catch (Exception e){}
                try
                {
                    NetState.BLOCKCHAIN_NODE_IP = tmp.getString("blockchain ip");
                }
                catch (Exception e){}

                JSONArray config = tmp.getJSONArray(CONFIGURATION);
                for (int i = 0; i < config.length(); i++) {
                    JSONObject daemon = (JSONObject) config.get(i);
                    Daemon instance;
                    if (daemon.getString(PORT).equals(LOCAL)) {
                        DeviceId deviceId = DeviceId.deviceId(daemon.getString(DEVICE));
                        IpAddress ipAddress = IpAddress.valueOf(daemon.getString(IP_ADDRESS));
                        MASTER.log.info("NO PROBLEM " + deviceId.toString());
                        instance = new DaemonForwarder(deviceId, ipAddress, PortNumber.LOCAL);
                        daemons.add(instance);
                    } else {
                        String port = "";
                        DeviceId deviceId = DeviceId.deviceId(daemon.getString(DEVICE));
                        IpAddress ipAddress = IpAddress.valueOf(daemon.getString(IP_ADDRESS));
                        port = daemon.getString(PORT);
                        PortNumber portNumber = PortNumber.portNumber(Long.parseLong(port));
                        MASTER.log.info("NO PROBLEM " + deviceId.toString());
                        instance = new DaemonForwarder(deviceId, ipAddress, portNumber);
                        daemons.add(instance);
                    }
                }
            }
            catch(Exception e)
            {
                String str = e.getLocalizedMessage();
                int i =0;
            }

        }
        return  daemons;
    }

    public static void setupParametersOfNetState()
    {
        JSONObject tmp = new JSONObject(configString);
        JSONObject obj2 = tmp.getJSONObject("parameters");
        JSONArray array = obj2.getJSONArray("list");
        for (int i = 0; i <array.length() ; i++)
        {
            JSONObject param = (JSONObject)array.get(i);

            try
            {
                Field[] fields = NetState.class.getDeclaredFields();
                for (int j = 0; j <fields.length; j++)
                {
                    Object obj = null;
                    try {
                        obj = fields[j].get(Class.forName("org.rnn.NetState"));
                    }
                    catch (Exception e){}
                    if(param!= null)
                    {
                        try {
                            if (fields[j].getAnnotatedType().getType() == Double.TYPE) {
                                fields[j].setDouble(obj, param.getDouble(fields[j].getName()));
                            }
                        }
                        catch (Exception ex1){}
                        try {
                            if (fields[j].getAnnotatedType().getType() == Integer.TYPE) {
                                fields[j].setInt(obj, param.getInt(fields[j].getName()));
                            }
                        }
                        catch (Exception ex2){}
                        try
                        {
                            fields[j].set(obj, param.getString(fields[j].getName()));
                        }
                        catch(Exception e)
                        {
                        }
                    }
                }
            }
            catch (Exception e)
            {
            }
        }
    }
}
