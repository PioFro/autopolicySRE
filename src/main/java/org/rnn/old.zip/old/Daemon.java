package org.rnn;

import org.onlab.packet.IpAddress;
import org.onosproject.net.DeviceId;
import org.onosproject.net.PortNumber;

public interface Daemon
{
    public DeviceId getDeviceId();
    public IpAddress getIpAddress();
    public PortNumber getPortNumber();
}
