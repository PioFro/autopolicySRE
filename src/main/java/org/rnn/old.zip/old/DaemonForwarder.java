package org.rnn;

import org.onlab.packet.IpAddress;
import org.onosproject.net.DeviceId;
import org.onosproject.net.PortNumber;

public class DaemonForwarder implements Daemon
{
    private DeviceId deviceId;

    private IpAddress ipAddress;

    private PortNumber portNumber;

    DaemonForwarder(DeviceId id, IpAddress ip, PortNumber port)
    {
        deviceId = id;
        ipAddress = ip;
        portNumber = port;
    }


    @Override
    public DeviceId getDeviceId()
    {
        return deviceId;
    }

    @Override
    public IpAddress getIpAddress() {
        return ipAddress;
    }

    @Override
    public PortNumber getPortNumber() {
        return portNumber;
    }

    public void setDeviceId(DeviceId deviceId) {
        this.deviceId = deviceId;
    }

    public void setIpAddress(IpAddress ipAddress) {
        this.ipAddress = ipAddress;
    }

    public void setPortNumber(PortNumber portNumber) {
        this.portNumber = portNumber;
    }

    @Override
    public String toString()
    {
        return "{  "+deviceId.toString()+"  ,  "+ipAddress.toString()+"  ,  PORT: "+portNumber.toString()+"  }";
    }

}
