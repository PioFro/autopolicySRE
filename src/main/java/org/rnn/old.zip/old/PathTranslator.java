
package org.rnn;

import org.onlab.packet.Ethernet;
import org.onlab.packet.IPv4;
import org.onlab.packet.IpAddress;
import org.onlab.packet.TpPort;
import org.onlab.packet.VlanId;
import org.onosproject.core.ApplicationId;
import org.onosproject.net.HostId;
import org.onosproject.net.PortNumber;
import org.onosproject.net.flow.DefaultTrafficSelector;
import org.onosproject.net.flow.DefaultTrafficTreatment;
import org.onosproject.net.flow.TrafficSelector;
import org.onosproject.net.flow.TrafficTreatment;
import org.onosproject.net.flowobjective.DefaultForwardingObjective;
import org.onosproject.net.flowobjective.ForwardingObjective;
import java.util.ArrayList;

/**
 * This class is a interface between RoutingModule and it's decisions and
 * controller's actions on particular devices.
 * @author Piotr Frohlich
 * @version Beta 2.0.0
 *
 *
 */
public class PathTranslator {
    /**
     * Instance of a AppComponent as it is the only one with access to
     * ForwardingObjectives class
     */
    private static AppComponent MASTER;

    /**
     * Lock access to list of New paths and installed path to avoid
     * concurrent modification exception
     */
    private static boolean lock = false;

    /**
     * Array of new paths, waiting to be installed.
     */
    protected static ArrayList<PathFlow> newPaths = new ArrayList<>();

    /**
     * Array of RoutingPathUnits being equivalent of installed paths and their
     * competitors.
     */
    private static ArrayList<RoutingPathUnit> installedPaths = new ArrayList<>();
    /**
     * Array of MultiRoutingInfo (for multi route flow rules)
     */
    private static ArrayList<MultiRoutingInfo> trafficInformation = new ArrayList<>();

    protected static long tmp = 0;
    /**
     * Constructor. Invoked in AppComponent's activate method.
     *
     * @param master       Instance of AppComponent.
     * @param defaultParam Default flow install interval in millis.
     */
    public PathTranslator(AppComponent master, int defaultParam)
    {
        MASTER = master;
        newPaths = new ArrayList<>();
        installedPaths = new ArrayList<>();
    }

    /**
     * Installation of given path in devices along it's way.
     *
     * @param pathFlow Path to install.
     * @param appId    AppId taken from NetState
     * @param topology Topology of whole network taken from NetState
     */
    public static void installPath(PathFlow pathFlow, ApplicationId appId, ArrayList<ForwardingDevice> topology) {
        int dest = pathFlow.destination;
        int src = pathFlow.source;
        for (int i = 0; i<pathFlow.getPath().size(); i++) {

            try {
                ArrayList<HostId> destinationHosts = topology.get(NetState.getForwardingDeviceBySimpleID(dest)).connectedHosts;
                ArrayList<HostId> sourceHosts = topology.get(NetState.getForwardingDeviceBySimpleID(src)).connectedHosts;

                for (int sourceIter = 0; sourceIter < sourceHosts.size(); sourceIter++) {
                    for (int destinationIter = 0; destinationIter < destinationHosts.size(); destinationIter++) {
                        if (MASTER.getIpAddressByHostId(destinationHosts.get(destinationIter)) != null && MASTER.getIpAddressByHostId(sourceHosts.get(sourceIter)) != null) {
                            //between clients
                            if(sourceHosts.get(sourceIter).vlanId().equals(VlanId.vlanId(((short)134)))==false&&destinationHosts.get(destinationIter).vlanId().equals(VlanId.vlanId((short)134))==false)
                            {

                                TrafficSelector.Builder selectorBuilder5005 = DefaultTrafficSelector.builder();
                                selectorBuilder5005
                                        .matchEthType(Ethernet.TYPE_IPV4)
                                        .matchEthDst(destinationHosts.get(destinationIter).mac())
                                        .matchEthSrc(sourceHosts.get(sourceIter).mac())
                                        .matchIPSrc(MASTER.getIpAddressByHostId(sourceHosts.get(sourceIter)).toIpPrefix())
                                        .matchIPDst(MASTER.getIpAddressByHostId(destinationHosts.get(destinationIter)).toIpPrefix()).build();

                                TrafficTreatment treatment5005 = DefaultTrafficTreatment.builder()
                                        .setOutput(PortNumber.portNumber(pathFlow.getPath().get(i).outputPort))
                                        .build();

                                ForwardingObjective forwardingObjective5005 = DefaultForwardingObjective.builder()
                                        .withSelector(selectorBuilder5005.build())
                                        .withTreatment(treatment5005)
                                        .withPriority(49999)
                                        .withFlag(ForwardingObjective.Flag.VERSATILE)
                                        .makePermanent()
                                        .fromApp(appId)
                                        .add();
                                MASTER.installFlowFromPath(forwardingObjective5005, topology.get(NetState.getForwardingDeviceBySimpleID(pathFlow.getPath().get(i).nodeDeviceId)).getDeviceControllerId());
                            }
                        }
                    }
                }
            }
            catch(Exception e)
            {

            }

            ForwardingDevice sourceDevice = NetState.getBySimpleID(src), destinationDevice = NetState.getBySimpleID(dest);
            //Between Forwarders

            for (int j = 0; j < sourceDevice.getDaemons().size(); j++)
            {
                for (int k = 0; k < destinationDevice.getDaemons().size(); k++)
                {

                    TrafficSelector.Builder selectorBuilder5004 = DefaultTrafficSelector.builder();
                    selectorBuilder5004
                            .matchEthType(Ethernet.TYPE_IPV4)
                            .matchIPProtocol(IPv4.PROTOCOL_UDP)
                            .matchUdpDst(TpPort.tpPort(5006))
                            .matchIPDst(destinationDevice.getDaemons().get(k).getIpAddress().toIpPrefix())
                            .matchIPSrc(sourceDevice.getDaemons().get(j).getIpAddress().toIpPrefix())
                            .build();
                    TrafficTreatment treatment5004 = DefaultTrafficTreatment.builder()
                            .setUdpDst(TpPort.tpPort(5004))
                            .setOutput(PortNumber.portNumber(pathFlow.getPath().get(i).outputPort))
                            .build();

                    ForwardingObjective forwardingObjective5004 = DefaultForwardingObjective.builder()
                            .withSelector(selectorBuilder5004.build())
                            .withTreatment(treatment5004)
                            .withPriority(50000)
                            .withFlag(ForwardingObjective.Flag.VERSATILE)
                            .makePermanent()
                            .fromApp(appId)
                            .add();
                    MASTER.installFlowFromPath(forwardingObjective5004, topology.get(NetState.getForwardingDeviceBySimpleID(pathFlow.getPath().get(i).nodeDeviceId)).getDeviceControllerId());
                }
            }
        }
        String result;
        result = VisAppComp.SetForwardingDevices(NetState.getTopology());


        if (NetState.LOG_VERBOSITY > -2) {
            MASTER.log.info("@INSTALATION OF PATH: " + pathFlow.toString() + " ENDED");
            //MASTER.log.info("VISUALISATION: "+result);
        }
    }

    /**
     * Installs given path as discovery flow for Cognitive Packets only.
     * @param pathFlow path to install
     */
    public static void installDiscoverypath(PathFlow pathFlow, int priority) {
        int dest = pathFlow.destination;
        int src = pathFlow.source;
        ForwardingDevice sourceDevice = NetState.getBySimpleID(src), destinationDevice = NetState.getBySimpleID(dest);

        for (Node node : pathFlow.getPath()) {
            for (int j = 0; j < sourceDevice.getDaemons().size(); j++)
            {
                for (int k = 0; k < destinationDevice.getDaemons().size(); k++)
                {
            TrafficSelector.Builder selectorBuilder5004 = DefaultTrafficSelector.builder();

            selectorBuilder5004
                    .matchEthType(Ethernet.TYPE_IPV4)
                    .matchIPProtocol(IPv4.PROTOCOL_UDP)
                    .matchUdpDst(TpPort.tpPort(5006))
                    .matchIPSrc(sourceDevice.getDaemons().get(j).getIpAddress().toIpPrefix())
                    .matchIPDst(destinationDevice.getDaemons().get(k).getIpAddress().toIpPrefix())
                    .build();
            TrafficTreatment treatment5004 = DefaultTrafficTreatment.builder()
                    .setUdpDst(TpPort.tpPort(5004))
                    .setOutput(PortNumber.portNumber(node.outputPort))
                    .build();

            ForwardingObjective forwardingObjective5004 = DefaultForwardingObjective.builder()
                    .withSelector(selectorBuilder5004.build())
                    .withTreatment(treatment5004)
                    .withPriority(priority)
                    .withFlag(ForwardingObjective.Flag.VERSATILE)
                    .makeTemporary(NetState.DEFAULT_DISCOVERY_FLOW_TIMEOUT)
                    .fromApp(NetState.getAppId())
                    .add();
            MASTER.installFlowFromPath(forwardingObjective5004, NetState.getTopology().get(NetState.getForwardingDeviceBySimpleID(node.nodeDeviceId)).getDeviceControllerId());
        }}}

        if (NetState.LOG_VERBOSITY > 0) {
            MASTER.log.info("@INSTALATION RANDOMIZED OF PATH: " + pathFlow.toString() + " ENDED");
        }
    }
    public static void installPathsWithMRI(PathFlow flow)
    {
        ArrayList<MultiRoutingInfo> mris = getMRIForSrcDst(flow.source, flow.destination);
        long bytesSentOverall = 0;
        for (int i = 0; i < mris.size(); i++)
        {
            bytesSentOverall += mris.get(i).getBytesSent();
        }
        RoutingPathUnit rpu = getAllPathsForSrcDst(flow.source, flow.destination);
        double scoreOverall =0, scoreOfBestPath = rpu.getBestPath().checkMeanScore();
        ArrayList<PathFlow> flows = new ArrayList<>();
        for (int i = 0; i < rpu.getPaths().size(); i++)
        {
            double tmpScore = rpu.getPaths().get(i).checkMeanScore();
            if(scoreOfBestPath<tmpScore)
            {
                scoreOverall+=tmpScore;
                flows.add(rpu.getPaths().get(i));
            }
            else if(scoreOfBestPath<=(tmpScore+NetState.DEFAULT_TRESHOLD))
            {
                scoreOverall+=tmpScore;
                flows.add(rpu.getPaths().get(i));
            }
        }
        for (int j = 0; j < mris.size(); j++)
        {   double mriFitnessCoverage= 0.5;
            try {
                mriFitnessCoverage = mris.get(j).getBytesSent() / bytesSentOverall;
            }catch (Exception e){}
            int idOfFlow = -1;
            double min = 2.0;
            for (int i = 0; i < flows.size(); i++)
            {
                double flowFitnessPercentage = 0.5;
                try {
                     flowFitnessPercentage = flows.get(i).checkMeanScore() / scoreOverall;
                }catch (Exception e){}
                if (flowFitnessPercentage>=mriFitnessCoverage)
                {
                    if(min > flowFitnessPercentage - mriFitnessCoverage)
                    {
                        min = flowFitnessPercentage - mriFitnessCoverage;
                        idOfFlow = i;
                    }
                }
            }
            if(idOfFlow != -1)
            {
                installPath(flows.get(idOfFlow),mris.get(j));
            }
            else installPath(flows.get(rpu.getBestPathIndex()), mris.get(j));
        }

    }
    public static void installPath(PathFlow flow, MultiRoutingInfo mri)
    {
        if(mri.isUsable() == false)
            return;
        MASTER.log.info("MOVEMENT FROM "+ mri.toString()+" DIRECTED VIA :"+flow.toString());
        for (int i = 0; i < flow.getPath().size(); i++) {
            TrafficSelector.Builder selectorBuilder5005 = DefaultTrafficSelector.builder();
            selectorBuilder5005
                    .matchEthType(Ethernet.TYPE_IPV4)
                    .matchIPProtocol(mri.getProto())
                    .matchIPSrc(mri.getSrc().toIpPrefix())
                    .matchIPDst(mri.getDst().toIpPrefix());
            if(mri.getProto() == IPv4.PROTOCOL_UDP) {
                if (mri.getTcpDstPort() != -1)
                    selectorBuilder5005.matchUdpDst(TpPort.tpPort(mri.getTcpDstPort()));
                if (mri.getTcpSrcPort() != -1)
                    selectorBuilder5005.matchUdpSrc(TpPort.tpPort(mri.getTcpSrcPort()));
            }
            if(mri.getProto() == IPv4.PROTOCOL_TCP) {
                if (mri.getTcpDstPort() != -1)
                    selectorBuilder5005.matchTcpDst(TpPort.tpPort(mri.getTcpDstPort()));
                if (mri.getTcpSrcPort() != -1)
                    selectorBuilder5005.matchTcpSrc(TpPort.tpPort(mri.getTcpSrcPort()));
            }
            TrafficTreatment treatment5005 = DefaultTrafficTreatment.builder()
                    .setOutput(PortNumber.portNumber(flow.getPath().get(i).outputPort))
                    .build();

            ForwardingObjective forwardingObjective5005 = DefaultForwardingObjective.builder()
                    .withSelector(selectorBuilder5005.build())
                    .withTreatment(treatment5005)
                    .withPriority(NetState.DEFAULT_NORMAL_PACKET_PRIORITY+1)
                    .withFlag(ForwardingObjective.Flag.VERSATILE)
                    .makePermanent()
                    .fromApp(MASTER.appId)
                    .add();
            MASTER.installFlowFromPath(forwardingObjective5005, NetState.getTopology().get(NetState.getForwardingDeviceBySimpleID(flow.getPath().get(i).nodeDeviceId)).getDeviceControllerId());
        }
    }

    /**
     * Adding new path to wait to being ready to be installed or stored for
     * later use.
     *
     * @param path given path.
     */
    public static void addNewPath(PathFlow path) {
        if (newPaths.size() > 0 && NetState.LOG_VERBOSITY > 1)
            MASTER.log.info("<><> [" + newPaths.size() + "]");
        if (containsPath(path, newPaths) == false)
        {
            MASTER.log.info("Path "+path.toString()+" added to new paths");
            path.setInstallationDueTime(System.currentTimeMillis() + NetState.DEFAULT_FLOW_INSTALL_INTERVAL);
            newPaths.add(path);
            addToRoutingPathUnit(path);
        }
    }

    /**
     * Check if given path has a equivalent in given array of paths
     *
     * @param path      given path
     * @param pathFlows given array of paths
     * @return true if in array exists pats that contains the same nodes as
     * given path. Otherwise false.
     */
    private static boolean containsPath(PathFlow path, ArrayList<PathFlow> pathFlows) {
        for (PathFlow pathFlow : pathFlows) {
            if (pathFlow.containsNodes(path))
                return true;
        }
        return false;
    }

    /**
     * Adding path to RoutingPathUnits array. Then RPU decides wheather this path
     * is better or worse than it's currently best.
     *
     * @param flow path to add to RPU
     * @return returns best path for RPU corresponding with given path src-dst
     * tuple
     */
    private static PathFlow addToRoutingPathUnit(PathFlow flow) {
        for (int i = 0; i < installedPaths.size(); i++) {
            if (flow.path.size() >= 1) {
                if (installedPaths.get(i).checkSourceDestination(flow.source, flow.destination)) {
                    PathFlow path = installedPaths.get(i).addPath(flow);
                    return path;
                }
            }
        }
        if (flow.path.size() >= 1) {
            installedPaths.add(new RoutingPathUnit(flow.source, flow.destination, flow, flow.srcHostId, flow.dstHostId));
            installPath(flow, NetState.getAppId(), NetState.getTopology());
        }
        return flow;
    }

    /**
     * Getter for best path corresponding to given src-dst tuple
     *
     * @param src src of src-dst tuple
     * @param dst dst of src-dst tuple
     * @return Best path that corresponds to given src-dst tuple
     */
    public static PathFlow getBestPathFromSrcDst(long src, long dst) {
        for (RoutingPathUnit rpu : installedPaths
        ) {
            if (rpu.checkSourceDestination(src, dst)) {
                return rpu.getBestPath();
            }
        }
        return null;

    }

    /**
     * Getter for best path corresponding to given src-dst tuple
     *
     * @param flow Path which corresponds to certain src-dst tuple
     * @return Best path that corresponds to src-dst tuple corresponding to given
     * path.
     */
    private static PathFlow getBestPathFromSrcDst(PathFlow flow) {
        for (RoutingPathUnit rpu : installedPaths
        ) {
            if (rpu.checkSourceDestination(flow.source, flow.destination)) {
                return rpu.getBestPath();
            }
        }
        return null;
    }

    /**
     * This is method used to run constantly. In this method firstly all newPaths
     * are checked if they are ready to install (installation time has passed).
     * Then paths are checked for emergency score drop. If their time has passed
     * or emergency drop was discovered they are moved to installation stage.
     * Then all of the paths that should be installed (paths in installation
     * stage, RPU) in this run are installed and the cycle starts again.
     */
    public static void checkPaths() {

        if (lock == true)
            return;

        lock = true;
        try {
            for (int i = 0; i < newPaths.size(); i++)//Adding paths
            {
                if (newPaths.get(i).getInstallationDueTime() <= System.currentTimeMillis()) {
                    addToRoutingPathUnit(newPaths.get(i));
                    if (NetState.LOG_VERBOSITY > 1)
                        MASTER.log.info("<<Path added to RPUs: " + newPaths.get(i).toString() + " cause timeout");
                    newPaths.remove(i);
                    if (NetState.LOG_VERBOSITY > 2)
                        MASTER.log.info("<<Path Removed. NewPathSize: [" + newPaths.size() + "]");

                }
                PathFlow tmpFlow = getBestPathFromSrcDst(newPaths.get(i));
                if (tmpFlow != null)//emergency rate drop check
                {
                    if (tmpFlow.calculateScore() - newPaths.get(i).calculateScore() > NetState.DEFAULT_TRESHOLD) {
                        addToRoutingPathUnit(newPaths.get(i));
                        if (NetState.LOG_VERBOSITY > 1)
                            MASTER.log.info("<<Path added to RPUs: " + newPaths.get(i).toString() + " cause treshold");
                        newPaths.remove(newPaths.get(i));
                    }
                }
            }
            for (int i = 0; i < installedPaths.size(); i++)//Installing all changed paths
            {
                installedPaths.get(i).calculateBestOption();
                if (installedPaths.get(i).isIdMaxChanged()) {
                    //TODO: CHANGE PREDEMO!!!!!
                    installPath(installedPaths.get(i).getBestPath(), NetState.getAppId(), NetState.getTopology());
                    //installPathsWithMRI(installedPaths.get(i).getBestPath());
                    installedPaths.get(i).setIdMaxChanged(false);
                }
                //installedPaths.get(i).checkForNewPossibilities();
            }
            if(tmp<System.currentTimeMillis())
            {
                tmp=System.currentTimeMillis()+100000;
                reinstallAllBestPaths();
            }

            lock = false;
        } catch (Exception e) {
            lock = false;
        }
    }

    /**
     * Update info about scores of given path.
     * @param flow New information about path's score
     */
    public static void updatePath(PathFlow flow) {
        for (int i = 0; i < installedPaths.size(); i++) {
            if (installedPaths.get(i).checkSourceDestination(flow.source, flow.destination)) {
                installedPaths.get(i).updatePathScore(flow);
                return;
            }
        }
        installedPaths.add(new RoutingPathUnit(flow.source, flow.destination, flow, HostId.NONE, HostId.NONE));
        //installPath(flow, NetState.getAppId(), NetState.getTopology());
    }
    /**
     * Getter for all the best paths stored in this class
     * @return list of best paths for all source-destination tuple which exists
     */
    public static ArrayList<PathFlow> getPaths() {
        ArrayList<PathFlow> paths = new ArrayList<>();

        for (RoutingPathUnit path : installedPaths) {
            paths.add(path.getBestPath());
        }
        return paths;
    }
    /**
     * Getter for all the all paths stored in this class
     * @return list of all paths for all source-destination tuple which exists
     */
    public static ArrayList<RoutingPathUnit> getAllPaths()
    {
        return installedPaths;
    }

    /**
     *
     */
    public static RoutingPathUnit getAllPathsForSrcDst(int src, int dst)
    {
        for (int i = 0; i < installedPaths.size(); i++)
        {
            if(installedPaths.get(i).checkSourceDestination(src, dst))
                return installedPaths.get(i);
        }
        return null;
    }
    /**
     * Getter for exactly the same path (same nodes and outputs)
     * @param flow flow to compare
     * @return Instance of the same path or null if there isn't such flow.
     */
    public static PathFlow getPathFlowConsistingOfNodes(PathFlow flow)
    {
        for (RoutingPathUnit rpu:installedPaths)
        {
            if(rpu.checkSourceDestination(flow.source, flow.destination))
            {
                for (int i = 0; i < rpu.getPaths().size(); i++)
                {
                    if(rpu.getPaths().get(i).containsNodes(flow))
                        return rpu.getPaths().get(i);
                }
            }

        }
        return null;
    }

    /**
     * Getter for all of the paths stored in Path Translator module for sake
     * of reinforcing security change impact on Network behaviour.
     * @return List of all paths stored inside Path Translator
     */
    public static ArrayList<PathFlow> getAllPathsForScoring()
    {
        ArrayList<PathFlow> paths = new ArrayList<>();
        for (int i = 0; i < installedPaths.size(); i++)
        {
            for (int j = 0; j < installedPaths.get(i).getPaths().size(); j++)
            {
                paths.add(installedPaths.get(i).getPaths().get(j));
            }

        }
        return paths;
    }


    /**
     * Reinstalls all current best paths for all known flows - in case some of
     * them were malformed.
     */
    private static void reinstallAllBestPaths()
    {
        for (int i = 0; i < getPaths().size() ; i++)
        {
            installPath(getPaths().get(i), NetState.getAppId(), NetState.getTopology());
        }
    }

    /**
     * Deletes all the paths with link that was put down
     * @param src source forwarder of link put down
     * @param dst destination forwarder of link put down
     */
    protected static void processLinkDown(int src, int dst)
    {
        for (int i = 0; i < installedPaths.size(); i++)
        {
            for (int j = 0; j < installedPaths.get(i).getPaths().size(); j++)
            {
                if(installedPaths.get(i).getPaths().get(j).hasLinkBetween(src, dst))
                {
                    if(installedPaths.get(i).getPaths().size()>1)
                    {
                        installedPaths.get(i).getPaths().remove(j);
                    }
                }

                installedPaths.get(i).setBestPathIndex(0);
            }
        }
    }

    protected static void addNewTrafficInformation(MultiRoutingInfo mri)
    {
        for (int i = 0; i < trafficInformation.size(); i++)
        {
            if(trafficInformation.get(i).equals(mri))
            {
                trafficInformation.get(i).active = true;
                return;
            }
        }
        trafficInformation.add(mri);
        return;
    }
    /**
     * Deletes all paths which are going through given device
     * @param simpleDeviceId Simple id of given device
     * @return Array with deleted path
     */
    protected static ArrayList<PathFlow> deletePathsWithDeviceId( int simpleDeviceId )
    {
        ArrayList<PathFlow> deletedPaths = new ArrayList<>();

        for (int i = 0; i < installedPaths.size(); i++)
        {
            for (int j = 0; j < installedPaths.get(i).getPaths().size(); j++)
            {
                if(installedPaths.get(i).getPaths().get(j).hasSimpleDeviceId(simpleDeviceId))
                {
                    deletedPaths.add(installedPaths.get(i).getPaths().get(j));
                    installedPaths.get(i).getPaths().remove(j);
                }
            }
        }
        return deletedPaths;
    }

    public static void checkTrafficInfo()
    {
        long timeNow = System.currentTimeMillis();

        for (int i = 0; i < trafficInformation.size(); i++)
        {
            if(trafficInformation.get(i).getTime()+NetState.MULTI_ROUTING_INFO_DEFAULT_TIMEOUT < timeNow)
            {
                long bytesSent = MASTER.getBytesOnMRI(trafficInformation.get(i));
                if(bytesSent!=trafficInformation.get(i).getBytesSent())
                {
                    trafficInformation.get(i).setBytesSent(bytesSent);
                }
                else
                {
                    //trafficInformation.get(i).active = false;
                }
                trafficInformation.get(i).setTime(System.currentTimeMillis());
            }

        }
    }
    public static ArrayList<MultiRoutingInfo> getTrafficInformation(){return trafficInformation;}
    public static ArrayList<MultiRoutingInfo> getMRIForSrcDst(int src, int dst)
    {
        ArrayList<MultiRoutingInfo> mris = new ArrayList<>();
        for (int i = 0; i <trafficInformation.size(); i++)
        {
            if(src == trafficInformation.get(i).getSrcDevice()&&dst == trafficInformation.get(i).getDstDevice())
            {
                mris.add(trafficInformation.get(i));
            }
        }
        return mris;
    }
    public static void updateBytesCountersOnFlows()
    {
        for (int i = 0; i <installedPaths.size(); i++)
        {
            for (int j = 0; j <installedPaths.get(i).getPaths().size(); j++)
            {
                installedPaths.get(i).getPaths().get(j).updateBytes();
            }
        }
    }


}
