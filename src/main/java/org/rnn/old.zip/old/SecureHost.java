
package org.rnn;

import org.onlab.packet.IpAddress;
import org.onosproject.net.HostId;

/**
 * Data container. Contains Tuples of Host and assigned to them: IP, Security Score, explanation and simple ID of device
 * to which host is connected.
 * @author Piotr Fr&ouml;hlich
 * @version Beta 2.0.0
 *
 */
public class SecureHost
{
    /**
     * ID of host. Assigned by controller.
     */
    private HostId hostId;

    /**
     * Level of security. Takes values <0,9></0,9> where 0 means completely safe, 9 means completely unsafe.
     */
    private int securityLevel;

    /**
     * IP address of corresponding host.
     */
    private IpAddress ipAddress;

    /**
     *Simple id of device to which host is connected to.
     */
    private int simpleID;

    /**
     * Verbose explanation of security rating. Given by PVT, administrator or whoever has access to REST interface of
     * controller.
     */
    private String explanation;

    /**
     *
     */

    /**
     * Contructor - all fields are filled with given parameters.
     * @param host Id of this host
     * @param lvl level of danger of this host
     * @param ipString primary IP of this host
     * @param explanation String explanation of value of score
     */
    public SecureHost(HostId host, int lvl, String ipString, String explanation)
    {
        hostId = host;
        securityLevel = lvl;
        ipAddress = IpAddress.valueOf(ipString);
        String[] array = ipString.split("\\.");
        this.explanation = explanation;
        simpleID = Integer.parseInt(array[array.length-1]);

    }

    /**
     * Constructor for endpoints without IP address. Notice that routing won't
     * consider them as endpoints but it will consider them as danger indicatiors.
     * @param host Id of this host
     * @param lvl level of danger of this host
     * @param explanation String explanation of value of score
     */
    public SecureHost(HostId host, int lvl, String explanation)
    {
        hostId = host;
        securityLevel = lvl;
        this.explanation = explanation;
        simpleID = host.hashCode();
    }

    @Deprecated
    /**
     * Check if given security level is higher than this of this instance.
     * @param lvl security level to check
     * @return True if given security level is higher. Otherwise false.
     */
    public boolean checkSecurityLevel(int lvl)
    {
        return (securityLevel<lvl);
    }

    /**
     * Parser to string.
     * @return String representation of class.
     */
    public String toString()
    {
        return hostId.toString()+"     IP:   "+ipAddress.toString()+"     SECURITY LEVEL: "+securityLevel+"  EXPLANATION:    "+ explanation;
    }

    /**
     * Getter for simpleID field
     * @return simple id of device to which this instance is connected.
     */
    public int getSimpleID(){return simpleID;}

    /**
     * Getter for security level field.
     * @return Integer value of security level of this instance.
     */
    public int getSecurityLevel(){return securityLevel;}

    /**
     * Getter for Host id field
     * @return id of this host
     */
    public HostId getHostId(){return hostId;}
}