
package org.rnn;

import org.onosproject.net.DeviceId;
import org.onosproject.net.PortNumber;

/**
 * Data container. Contains tuples of port number and device id connected to this port of certain device. Used to
 * speed up links search.
 * @author Piotr Frohlich
 * @Version Beta 2.0.0
 *
 *
 */
public class PortDeviceIdTuple
{
    /**
     * Long representation of port number on certain device.
     */
    public long portNumber;

    /**
     * Real port number on certain device
     */
    public PortNumber actualPortNumber;

    /**
     * Device Id of device connected to this port.
     */
    public DeviceId deviceId;

    /**
     * Constructor
     * @param port Port of certain device.
     * @param id Id of device connected to given port.
     */
    public PortDeviceIdTuple(long port, DeviceId id, PortNumber realPort)
    {
        portNumber = port;
        deviceId = id;
        actualPortNumber = realPort;
    }
}
