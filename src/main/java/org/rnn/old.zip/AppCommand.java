/*
 * Copyright 2018-present Open Networking Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.rnn;

import org.apache.karaf.shell.commands.Argument;
import org.apache.karaf.shell.commands.Command;
import org.onosproject.cli.AbstractShellCommand;
import org.onosproject.net.HostId;
import org.onosproject.net.Path;
import sun.nio.ch.Net;

import java.lang.reflect.Field;
import java.util.ArrayList;
/**
 * @author Piotr Frohlich
 * @version Beta 2.0.0
 * CLI Manager Class
 */
@Command(scope = "onos", name = "dump-rnn-module",
         description = "Dump whole rnns' structures")
public final class AppCommand extends AbstractShellCommand {

    @Argument(index = 0, name = "parameter", description = "Decide what do you want " +
            "to be listed. D for devices, P for paths, H for hosts and T for delay info." +
            "To see all paths (not only best ones) type +. To see all" +
            " output type DP+HT ",
            required = false, multiValued = false)
    String parameter = null;

    /**
     * Executes cli command dump-rnn-module, which prints all data on the console.
     */
    @Override
    protected void execute() {


        if(parameter!=null) {

            if (parameter.contains("H") || parameter.contains("h")) {
                for (SecureHost sHost : NetState.getSecureHosts()) {
                    print(sHost.toString());

                }
            }
            if(parameter.contains("D")|| parameter.contains("d")) {
                //print("DEVICES:\n_________________________________________________\n");
                for (ForwardingDevice fd : NetState.getTopology()) {
                    print("DEVICE: [" + fd.getDeviceControllerId().toString()+" , simpleID: "+fd.getSimpleID());
                    print("HOSTS: [");
                    String hosts = "";
                    for (HostId id : fd.connectedHosts) {
                        hosts+=(id.toString() + " , ");
                    }
                    print(hosts+"]");
                    print("LINKS: [ ");
                    String links = "";
                    for (PortDeviceIdTuple tuple : fd.links) {
                        links +="(PORT :" + tuple.portNumber + "/ " + tuple.deviceId.toString() + "/" + tuple.actualPortNumber.toString() + ")  ,  ";
                    }
                    print(links +"] ");
                    print("SENSITIVITY: " + fd.getSensivity() + "\nDAEMONS: ");
                    String daemons = "";
                    for (int i = 0; i < fd.getDaemons().size(); i++) {
                        daemons+=(fd.getDaemons().get(i).toString()+" , ");
                    }
                    print(daemons+"]");
                    print("FULLNESS: " + fd.previousBytesOverall + "/" + fd.MAX_BYTES_THROUGHPUT);

                }
            }
            if(parameter.contains("P")||parameter.contains("p")) {
                int j = 0;
                for (RoutingPathUnit rpu : PathTranslator.getAllPaths()) {
                    //print("\t\t[ " + j + " ]\n");
                    j++;
                    int i = 0;
                    for (PathFlow path : rpu.getPaths()) {
                        if (i == rpu.getBestPathIndex())
                            print("**(" + path.source + "," + path.destination + ")" + "    PATH: " + path.toString());
                        else
                            if(parameter.contains("+")) {
                                print("\t(" + path.source + "," + path.destination + ")" + "    PATH: " + path.toString());
                            }
                        i++;
                    }
                    print("\n");
                }
            }
            if(parameter.contains("T")||parameter.contains("t")) {
                ArrayList<DelayAgregator.DelayLinkIdTuple> tmp = RnnRouting.getDelayAgregator().getLinkIDDelayInfoHashMap();
                for (int i = 0; i < tmp.size(); i++) {
                    print(tmp.get(i).toString() + "");
                    /**if (tmp.get(i).delayInfo.delay > 300) {
                        PathTranslator.processLinkDown((int) tmp.get(i).linkID.src, (int) tmp.get(i).linkID.dst);

                        PathTranslator.processLinkDown((int) tmp.get(i).linkID.dst, (int) tmp.get(i).linkID.src);
                    }**/
                }
            }

            if(parameter.equals("n"))
            {
                try {
                    Field[] fields = NetState.class.getDeclaredFields();
                    for (int i = 0; i < fields.length; i++) {
                        try {
                            print(fields[i].getName() + "   :   " + fields[i].get(new Object()).toString());
                        }
                        catch (Exception e)
                        {}
                    }
                }
                catch (Exception e)
                {}
            }

        }
        print("DEVICES: "+ NetState.getTopology().size());
        ArrayList<MultiRoutingInfo> tmp = PathTranslator.getTrafficInformation();
        if(parameter.contains("M") || parameter.contains("m")) {
            for (int i = 0; i < tmp.size(); i++) {
                if (tmp.get(i).isUsable()) {
                    print(tmp.get(i).toString());
                }
            }
        }

    }
}
